#include <iostream>
using namespace std;
class CTime{
    private:
        int hour;
        int minute;
        int second;
    public:
        CTime(int H=0,int M=0,int S=0);
        CTime(CTime &t);
        ~CTime();

        void setHour(int H);
        int getHour();
        void setMinute(int M);
        int getMinute();
        void setSecond(int S);
        int getSecond();

        void show();
};
//���캯����ע��ȱʡ������ʹ��
CTime::CTime(int H,int M,int S){
    hour=H;
    minute=M;
    second=S;
    while(second>=60){
        second=second-60;
        minute=minute+1;
    }
    while(minute>=60){
        minute=minute-60;
        hour=hour+1;
    }
    hour=hour%24;
    cout<<"Constructor run"<<endl;
}
//�������캯��
CTime::CTime(CTime &t){
    hour=t.hour;
    minute=t.minute;
    second=t.second;
    cout<<"CopyConstructor run"<<endl;
}
//��������
CTime::~CTime(){
    cout<<"Destructor run"<<endl;
}
//����"ʱ"����
void CTime::setHour(int H){
    hour=H%24;
}
//��ȡ"ʱ"����
int CTime::getHour(){
    return hour;
}
//����"��"����
void CTime::setMinute(int M){
    minute=M;
    while(minute>=60){
        minute=minute-60;
        hour=hour+1;
    }
    hour=hour%24;
}
//��ȡ"��"����
int CTime::getMinute(){
    return minute;
}
//����"��"����
void CTime::setSecond(int S){
    second=S;
    while(second>=60){
        second=second-60;
        minute=minute+1;
    }
    while(minute>=60){
        minute=minute-60;
        hour=hour+1;
    }
    hour=hour%24;
}
//��ȡ"��"����
int CTime::getSecond(){
    return second;
}
//��ʾʱ��
void CTime::show(){
    cout<<hour<<":"<<minute<<":"<<second<<endl;
}

int main(){
    CTime t(25,32,69);
    t.show();
    return 0;
}

